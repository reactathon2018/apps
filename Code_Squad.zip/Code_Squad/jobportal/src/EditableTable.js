import React from 'react';
import { upperFirst } from 'lodash/string';
import {
  DataTable,
  TableHeader,
  TableBody,
  TableRow,
  TableColumn,
  EditDialogColumn,
  SelectFieldColumn,
} from 'react-md';

const desserts = [{

    Sequence: '1',
  
    From: 'Ice cream',
  
    calories: 159,
  
    fat: 6.0,
  
    carbs: 24,
  
    protein: 4.0,
  
    sodium: 87,
  
    calcium: 14,
  
    iron: 1,
  
  }, {
  
    Sequence: '2',
  
    From: 'Ice cream',
  
    calories: 237,
  
    fat: 9.0,
  
    carbs: 37,
  
    protein: 4.3,
  
    sodium: 129,
  
    calcium: 8,
  
    iron: 1,
  
  }, {
  
    Sequence: '3',
  
    From: 'Pastry',
  
    calories: 262,
  
    fat: 16.0,
  
    carbs: 37,
  
    protein: 6.0,
  
    sodium: 337,
  
    calcium: 6,
  
    iron: 7,
  
  }, {
  
    Sequence: '4',
  
    From: 'Pastry',
  
    calories: 305,
  
    fat: 3.7,
  
    carbs: 67,
  
    protein: 4.3,
  
    sodium: 413,
  
    calcium: 3,
  
    iron: 8,
  
  }, {
  
    Sequence: '5',
  
    From: 'Pastry',
  
    calories: 356,
  
    fat: 16.0,
  
    carbs: 49,
  
    protein: 3.9,
  
    sodium: 327,
  
    calcium: 7,
  
    iron: 16,
  
  }, {
  
    Sequence: '6',
  
    From: 'Other',
  
    calories: 375,
  
    fat: 0.0,
  
    carbs: 94,
  
    protein: 0.0,
  
    sodium: 50,
  
    calcium: 0,
  
    iron: 0,
  
  }, {
  
    Sequence: '7',
  
    From: 'Other',
  
    calories: 392,
  
    fat: 0.2,
  
    carbs: 98,
  
    protein: 0.0,
  
    sodium: 38,
  
    calcium: 0,
  
    iron: 2,
  
  }, {
  
    Sequence: '8',
  
    From: 'Other',
  
    calories: 408,
  
    fat: 3.2,
  
    carbs: 87,
  
    protein: 6.5,
  
    sodium: 562,
  
    calcium: 0,
  
    iron: 45,
  
  }, {
  
    Sequence: '9',
  
    From: 'Pastry',
  
    calories: 52,
  
    fat: 25.0,
  
    carbs: 51,
  
    protein: 4.9,
  
    sodium: 326,
  
    calcium: 2,
  
    iron: 22,
  
  }, {
  
    Sequence: '10',
  
    From: 'Other',
  
    calories: 16,
  
    fat: 6.0,
  
    carbs: 65,
  
    protein: 7.0,
  
    sodium: 54,
  
    calcium: 12,
  
    iron: 6,
  
  }];
const headers = Object.keys(desserts[0]).map((Sequence, i) => ({
  key: Sequence ,
  Sequence : upperFirst(Sequence),
  numeric: i > 1,
  selectColumnHeader: i === 1,
}));
const types =  [{
    type: 'In Progress',
    type: 'Done',

}];



const EditableTables = () => (
  <DataTable baseId="table-with-interactions">
    <TableHeader>
      <TableRow>
        {headers.map(({ Sequence , ...props }, i) => <TableColumn {...props} grow={i === 0}>{Sequence }</TableColumn>)}
      </TableRow>
    </TableHeader>
    <TableBody>
      {desserts.map(({ Sequence , type, calories, fat, carbs, protein, sodium, calcium, iron }) => (
        <TableRow key={Sequence }>
          <EditDialogColumn defaultValue={Sequence } label="Name" placeholder="Yummy food" />
          <SelectFieldColumn menuItems={types} defaultValue={type} />
          <TableColumn numeric>{calories}</TableColumn>
          <TableColumn numeric>{fat}</TableColumn>
          <TableColumn numeric>{carbs}</TableColumn>
          <TableColumn numeric>{protein}</TableColumn>
          <TableColumn numeric>{sodium}</TableColumn>
          <TableColumn numeric>{calcium}</TableColumn>
          <TableColumn numeric>{iron}</TableColumn>
        </TableRow>
      ))}
    </TableBody>
  </DataTable>
);

export default EditableTables;