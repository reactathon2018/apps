import React, { Component } from 'react';
import ApolloClient from 'apollo-boost';
import { ApolloProvider } from 'react-apollo';
import image2 from './keep.jpg';
import image4 from './coding.jpg';
import image5 from './dojo.jpg';
import image7 from './progarmmin2.jpg';
import image8 from './background.jpeg';
import Login from './components/Login';
import Events from './components/Events';
import BarChart2 from './components/BarChart2';
import BarChart3 from './components/BarChart3';
import App from './App';

import './components/BarChart.css';

import {
    BrowserRouter as Router,
    Link,
    Route,
    Switch,
    Redirect
  } from 'react-router-dom';

import {
    Carousel,
  CarouselItem,
  CarouselControl,
  CarouselIndicators,
  CarouselCaption,
  Jumbotron
    } from 'reactstrap';



const items = [
    {
      src:image5,
      altText: 'Slide 1',
      caption: ''
    },
    {
     src:image4,
      altText: 'Slide 2',
      caption: ''
    },
    {
        src:image2,
        altText: 'Slide 3',
      caption: ''
    }
  ];
  const Apps = () => (
    <Router>
      <div>
        <Switch>
          <Route path="/Events" component={Events} />
          <Route path="/" component={FrontPage} />
          <Route
            path="/contact"
            render={() => <h1>Contact Us</h1>} />
          <Route path="/blog" children={({match}) => (
            <li className={match ? 'active' : ''}>
              <Link to="/blog">Blog</Link>
            </li>)} />
          <Route render={() => <h1>Page not found</h1>} />
        </Switch>
      </div>
    </Router>
  );  
var chartStyle={
    height:"500px",
    width:"900px"
};
  class FrontPage extends Component {
      
    constructor(props) {
      super(props);
      this.state = { activeIndex: 0 };
      this.next = this.next.bind(this);
      this.previous = this.previous.bind(this);
      this.goToIndex = this.goToIndex.bind(this);
      this.onExiting = this.onExiting.bind(this);
      this.onExited = this.onExited.bind(this);
    }
  
    onExiting() {
      this.animating = true;
    }
  
    onExited() {
      this.animating = false;
    }
  
    next() {
      if (this.animating) return;
      const nextIndex = this.state.activeIndex === items.length - 1 ? 0 : this.state.activeIndex + 1;
      this.setState({ activeIndex: nextIndex });
    }
  
    previous() {
      if (this.animating) return;
      const nextIndex = this.state.activeIndex === 0 ? items.length - 1 : this.state.activeIndex - 1;
      this.setState({ activeIndex: nextIndex });
    }
  
    goToIndex(newIndex) {
      if (this.animating) return;
      this.setState({ activeIndex: newIndex });
    }

    
  
    render() {
      const { activeIndex } = this.state;
  
      const slides = items.map((item) => {
        return (
          <CarouselItem
            onExiting={this.onExiting}
            onExited={this.onExited}
            key={item.src}
          >
            <img className="imageStyle" src={item.src} alt={item.altText} />
            <CarouselCaption captionText={item.caption} captionHeader={item.caption} />
          </CarouselItem>
        );
      });
  
      return (<div>
        {/*<App/>*/}
            <Jumbotron>
                <h1 className="display-3">Welcome to  Hackathon portal</h1>
                <p className="lead">Are you interested in hackathons??!!!If yes,You've landed at the right place</p>
            </Jumbotron>
            <Carousel
                activeIndex={activeIndex}
                next={this.next}
                previous={this.previous}
                >
                <CarouselIndicators items={items} activeIndex={activeIndex} onClickHandler={this.goToIndex} />
                {slides}
                <CarouselControl direction="prev" directionText="Previous" onClickHandler={this.previous} />
                <CarouselControl direction="next" directionText="Next" onClickHandler={this.next} />
             </Carousel>
             <div>
             <Login/>
             </div>

             {/*management*/}
             <div className="App">
        <header className="App-header">
        <h1 className="App-title">Management View</h1>
        </header>
        {/* <svg id="chart"></svg><br/> */}
                
            <div>
                <div className="divWidth">
                    <p>Date-vise Event chart for the current year</p>
                    <svg id="chart2"></svg>
                    <BarChart2
                    data={[
                    {date:new Date(2018, 1, 1), event:{name:'Event1', count:300}, orgs:{org1:50, org2:110, org3: 80, org4: 60}},
                    {date:new Date(2018, 1, 30), event:{name:'Event2', count:200}, orgs:{org1:30, org2:60, org3: 60, org4: 50}},
                    {date:new Date(2018, 2, 10), event:{name:'Event3', count:500}, orgs:{org1:80, org2:140, org3: 180, org4: 100}},
                    {date:new Date(2018, 3, 5), event:{name:'Event4', count:330}, orgs:{org1:60, org2:120, org3: 80, org4: 70}},
                    {date:new Date(2018, 4, 15), event:{name:'Event5', count:230}, orgs:{org1:50, org2:90, org3: 55, org4: 35}},
                    {date:new Date(2018, 6, 6), event:{name:'Event6', count:200}, orgs:{org1:60, org2:30, org3: 70, org4: 40}},
                    {date:new Date(2018, 7, 2), event:{name:'Event7', count:510}, orgs:{org1:150, org2:110, org3: 180, org4: 70}}
                    ]}
                    />
                </div>
                <div className="divWidth divFloat">
                    <p>Org-vise Participation chart for the current year</p>
                    <svg id="chart3" style={chartStyle}></svg> 
                    <BarChart3
                    data={[
                    {date:new Date(2018, 1, 1), org1:50, org2:110, org3: 80, org4: 60},
                    {date:new Date(2018, 1, 30), org1:30, org2:60, org3: 60, org4: 50},
                    {date:new Date(2018, 2, 10), org1:80, org2:140, org3: 180, org4: 100},
                    {date:new Date(2018, 3, 5), org1:60, org2:120, org3: 80, org4: 70},
                    {date:new Date(2018, 4, 15), org1:50, org2:90, org3: 55, org4: 35},
                    {date:new Date(2018, 6, 6), org1:60, org2:30, org3: 70, org4: 40},
                    {date:new Date(2018, 7, 2), org1:150, org2:110, org3: 180, org4: 70}
                    ]}/>
                </div>
                </div>
                <p>Winners!</p>
                <table>
                    <tr>
                    <th>Event</th>
                    <th>Winner</th>
                    <th>Org</th>
                    </tr>
                    <tr>
                    <td>Event1</td>
                    <td>Team1</td>
                    <td>Org1</td>
                    </tr>
                    <tr>
                    <td>Event2</td>
                    <td>Team2</td>
                    <td>org2</td>
                    </tr>
                    <tr>
                    <td>Event3</td>
                    <td>Team3</td>
                    <td>org3</td>
                    </tr>
                    <tr>
                    <td>Event4</td>
                    <td>Team4</td>
                    <td>org4</td>
                    </tr>
                    <tr>
                    <td>Event5</td>
                    <td>Team5</td>
                    <td>org5</td>
                    </tr>
                    <tr>
                    <td>Event6</td>
                    <td>Team6</td>
                    <td>org6</td>
                    </tr>
                    <tr>
                    <td>Event7</td>
                    <td>Team7</td>
                    <td>org7</td>
                    </tr>
                </table>
            </div>
            )
        </div>
      );
    }
  }
  
  
  export default FrontPage;
