import React, { Component } from 'react';
import ApolloClient from 'apollo-boost';
import { ApolloProvider } from 'react-apollo';

import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    Carousel,
    CarouselItem,
    CarouselControl,
    CarouselIndicators,
    CarouselCaption
   } from 'reactstrap';

// components
import UserList from './components/UserList';
import Events from './components/Events';
// import AddUser from './components/AddUser';

// apollo client setup
const client = new ApolloClient({
    uri: 'http://localhost:4000/graphql'
});



class App extends Component {
    constructor(props) {
        super(props);
    
        this.toggle = this.toggle.bind(this);
        this.state = {
          isOpen: false
        };
      }
      toggle() {
        this.setState({
          isOpen: !this.state.isOpen
        });
      }

  render() {
    return (
        <ApolloProvider client={client}>
        { /*<img className='bg' src={'keep-calm-and-try-coding-850x468.png'} /> */}
        <div>
       <Navbar color="light" light expand="md">
          <NavbarBrand href="/"><b>Reactors</b></NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
              <NavItem>
                <NavLink href="/activeEvents/">Ongoing Events</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/historicalEvents/">Past Events</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/upcomingEvents/">Upcoming Events</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/managementPortal/">Management Portal</NavLink>
              </NavItem>
                <UncontrolledDropdown nav inNavbar>
                    <DropdownToggle nav caret>
                    Technology
                    </DropdownToggle>
                        <DropdownMenu right>
                        <DropdownItem>
                            <NavLink href="https://nodejs.org/en/">NodeJS</NavLink>
                        </DropdownItem>
                        <DropdownItem>
                            <NavLink href="https://reactjs.org/">React</NavLink>
                        </DropdownItem>
                    <DropdownItem divider />
                        <DropdownItem>
                            <NavLink href="https://angular.io/">Angular</NavLink>
                        </DropdownItem>
                    </DropdownMenu>
                </UncontrolledDropdown>
            </Nav>
          </Collapse>
        </Navbar>
      </div>


            <div id="main">
                <h1>Hackathon Management Portal</h1>
                <div id="userPositions">
                <h3 id="positions">Leader Board</h3>
                    <UserList />
                </div >
                <div id="eventList">
                <h3 id="positions" >Ongoing Events </h3>
                <Events/>
                </div>
            </div>
        </ApolloProvider>
    );
  }
}

export default App;
