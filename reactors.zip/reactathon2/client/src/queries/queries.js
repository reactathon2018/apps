import { gql } from 'apollo-boost';

const addBookMutation = gql`
    mutation AddBook($name: String!, $genre: String!, $authorId: ID!){
        addBook(name: $name, genre: $genre, authorId: $authorId){
            name
            id
        }
    }
`;

const getBookQuery = gql`
    query GetBook($id: ID){
        book(id: $id) {
            id
            name
            genre
            author {
                id
                name
                age
                books {
                    name
                    id
                }
            }
        }
    }
`;


const getUsersQuery = gql`
    {
        users{
            id
            firstName
            lastName
            emailId
            contact
            org
        }
    }
`;


const getEventsQuery = gql`
    {
        events{
            id
            name
            venue
            description
            
        }
    }
`;

export {getUsersQuery ,getEventsQuery};
