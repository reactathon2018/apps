import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import FrontPage from './FrontPage';
import 'bootstrap/dist/css/bootstrap.min.css';


ReactDOM.render(<FrontPage />, document.getElementById('root'));
