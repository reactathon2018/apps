
import React, { Component } from 'react';
import * as d3 from 'd3';
import {withFauxDOM} from 'react-faux-dom';

class BarChart extends React.Component {
    componentDidMount () {
      const faux = this.props.connectFauxDOM('div', 'chart')
      d3.select(faux)
        .append('div')
        .html('Hello')
      this.props.animateFauxDOM(800);
    debugger;
    var chart = document.getElementById("chart3");
    var svg = d3.select(chart),
      margin = {top: 20, right: 20, bottom: 30, left: 40},
      width = 960 - margin.left - margin.right,
      height = 500 - margin.top - margin.bottom,
      g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    var x = d3.scaleBand()
        .rangeRound([0, width])
        .paddingInner(0.05)
        .align(0.1);

    var y = d3.scaleLinear()
        .rangeRound([height, 0]);

    var z = d3.scaleOrdinal()
        .range(["#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"]);

    var data = this.props.data;
  // fix pre-processing
    var keys = [];
    for (var key in data[0]){
        if (key != "date")
        keys.push(key);
    }
    data.forEach(function(d){
        d.total = 0;
        keys.forEach(function(k){
            d.total += d[k];
        })
    });

    // data.sort(function(a, b) {
    //     return b.total - a.total;
    // });
    x.domain(data.map(function(d) {
        return d.date;
    }));
    y.domain([0, d3.max(data, function(d) {
        return d.total;
    })]).nice();
    z.domain(keys);
debugger;
    g.append("g")
        .selectAll("g")
        .data(d3.stack().keys(keys)(data))
        .enter().append("g")
        .attr("fill", function(d) {
        return z(d.key);
        })
        .selectAll("rect")
        .data(function(d) {
        return d;
        })
        .enter().append("rect")
        .attr("x", function(d) {
        return x(d.data.date);
        })
        .attr("y", function(d) {
        return y(d[1]);
        })
        .attr("height", function(d) {
        return y(d[0]) - y(d[1]);
        })
        .attr("width", x.bandwidth())
        .on("mouseover", function() { tooltip.style("display", null); d3.select(this).attr("fill", "#588C73")})
        .on("mouseout", function(d, i) { tooltip.style("display", "none");d3.select(this).attr("fill", function() {
                return "";
        });})
        .on('mousemove', function(d, i) {
            var thisName = d3.select(this.parentNode).datum().key;
            var thisValue = d.data[thisName];
            tooltip
              .style("left", d3.event.pageX - 50 + "px")
              .style("top", d3.event.pageY - 70 + "px")
              .style("display", "inline-block")
              .html("<b>Name:</b>"+(thisName) + "<br>" + "<b>Participants:</b>" + (thisValue));
        })        
        .attr("class", "bar");;

    g.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x).tickFormat(d3.timeFormat("%Y-%m-%d")));

    g.append("g")
        .attr("class", "axis")
        .call(d3.axisLeft(y).ticks(null, "s"))
        .append("text")
        .attr("x", 2)
        .attr("y", y(y.ticks().pop()) + 0.5)
        .attr("dy", "0.32em")
        .attr("fill", "#000")
        .attr("font-weight", "bold")
        .attr("text-anchor", "start")
        .text("Total Participation");
    
    var legend = g.append("g")
        .attr("font-family", "sans-serif")
        .attr("font-size", 10)
        .attr("text-anchor", "end")
        .selectAll("g")
        .data(keys.slice().reverse())
        .enter().append("g")
        .attr("transform", function(d, i) {
        return "translate(0," + i * 20 + ")";
        });

    legend.append("rect")
        .attr("x", width - 300)
        .attr("width", 19)
        .attr("height", 19)
        .attr("fill", z);

    legend.append("text")
        .attr("x", width - 305)
        .attr("y", 9.5)
        .attr("dy", "0.32em")
        .text(function(d) {
        return d;
        });

    //     var tooltip = g.append("g")
    // .attr("class", "tooltip")
    // .style("display", "none");
    var tooltip = d3.select("body").append("div").attr("class", "toolTip");
      
  //Creación del rectángulo del tooltip
  tooltip.append("rect")
    .attr("width", 360)
    .attr("height", 22)
    .attr("fill", "white")
    .style("opacity", 0.4);
  //Justificación del texto en el rectángulo
  tooltip.append("text")
    .attr("x", 2)
    .attr("dy", "1.2em")
    .style("text-anchor", "center")
    .attr("font-size", "12px")
    .attr("font-weight", "bold");
    }
   
    render () {
      return (
        <div>
        </div>
      )
    }
  }
   
  BarChart.defaultProps = {
    chart: 'loading'
  }
   
  export default withFauxDOM(BarChart)