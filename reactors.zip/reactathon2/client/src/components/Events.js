import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { getEventsQuery } from '../queries/queries';
import { ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText,
    Button, Modal, ModalHeader, ModalBody, ModalFooter,
    Table  } from 'reactstrap';


// components
// import BookDetails from './BookDetails';

class Events extends Component {
    constructor(props) {
        super(props);
        this.state = {
          modal: false
        };
    
        this.toggle = this.toggle.bind(this);
      }
    
      toggle() {
        this.setState({
          modal: !this.state.modal
        });
      }


    render(){
        var data = this.props.data;
        if(data.loading){
            return( <div>Loading events...</div> );
        } else {
            return (
                <ListGroup>
                        { data.events.map(event => {
                            return (<ListGroupItem key={event.id} onClick={this.toggle}>
                                        <Modal isOpen={this.state.modal} toggle={this.toggle}>
                                            <ModalHeader toggle={this.toggle}>Event Details</ModalHeader>
                                            <ModalBody>
                                                <Table dark>
                                                    <tbody>
                                                        <tr>
                                                            <td>Event Name</td>
                                                            <td>{event.name}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Venue</td>
                                                            <td>{event.venue}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Time</td>
                                                            <td>{event.time}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Prize</td>
                                                            <td>{event.prize}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Description</td>
                                                            <td>{event.description}</td>
                                                        </tr>
                                                    </tbody>
                                                </Table>
                                            </ModalBody>
                                            <ModalFooter>
                                                <Button color="secondary" onClick={this.toggle}>Cancel</Button>
                                            </ModalFooter>
                                        </Modal>
                                    <ListGroupItemHeading>{ event.name }</ListGroupItemHeading>
                                    <ListGroupItemText>
                                    {event.time} | { event.description}
                                    </ListGroupItemText>
                            </ListGroupItem>
                        )
                        })}
                    </ListGroup>
            )
        }
    }
}

export default graphql(getEventsQuery)(Events);
