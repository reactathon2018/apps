import React, { Component } from "react";
import style from "./Login.css";




export default class Login extends Component {



    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    
        this.state = {
          username: "",
          password: ""
        };
      }


      
      
        handleChange = event => {

          const target = event.target;
          const value =target.value;
          const name = target.name;

  this.setState({
    [name]: value
  });
          
        }
      
        handleSubmit = event => {
          console.log('this is submit:', this.state.username);
     
        if(this.state.username!=null && this.state.username !=''){
          fetch('http://localhost:4000/validateLogin', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username: this.state.username,
      password: this.state.password
    
    })
  }).then(response=> response.text()).then((response)=>{console.log(response);if(response.indexOf('Pass')>-1){ 
  console.log('redirect here'); 
    
}else if(response.indexOf('No record')>-1){

    alert('User Id not Found . Please Register');
  }else{
     
    alert('Incorrect login details') ;

  }}) ;
        
        }
     

        }
        handleClick = () => {
let isFieldEmpty =true ;
let userExists =false;
let userAdded=false ;
let username='' ;
let password='' ;
 if(this.state.fname_new!=null && this.state.fname_new!='' && this.state.lname_new!=null && this.state.lname_new !='' && this.state.contact!=null && this.state.contact!='' && this.state.org!=null && this.state.org!='' && this.state.password_new!=null &&this.state.password_new!='' && this.state.confirm_password_new!=null && this.state.confirm_password_new!='' && this.state.emailId_new !=null && this.state.emailId_new!='' ){
  isFieldEmpty=false ;
  username=this.state.emailId_new ;

 }
 let isPasswordSame=false;
    if(!isFieldEmpty){
      if(this.state.password_new == this.state.confirm_password_new){
        isPasswordSame=true
        password=this.state.confirm_password_new;
      }
 if(isPasswordSame){

  fetch('http://localhost:4000/validateUser?emailId='+this.state.emailId_new).then(response => response.text()).then((response) =>{
  if(response.indexOf('User already exists')>-1)  
  userExists=true ;
  }) ;

}

if(userExists){

  alert('User Id already Exists') ;
}else{


  fetch('http://localhost:4000/addUser', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      fName: this.state.fname_new,
      lName: this.state.lname_new,
      emailId:this.state.emailId_new ,
      contact:this.state.contact ,
      details :{} ,
      org :this.state.org
    })
  }).then(response=> response.text()).then((response)=>{console.log(response);if(response.indexOf('item saved to database')>-1) 
  addPasswordMapping(); }) ;

function addPasswordMapping(){

fetch('http://localhost:4000/addPasswordMapping', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username: username,
      password: password,
      
    })
  }) ;
}

}

}

 }

 
          
         


          


          
        

            
           

  
            


            
          

          render() {
            return (
                <div className="loginContainer">
                <form id="loginForm">
                <h2 >User Login/Register</h2>
                <div className="row">
             
                <div className="vl">
                  <span className="vl-innertext" >or</span>
                </div>
          
                <div className="loginStyle">
                <input type="text" name="username" placeholder="Username" onChange={this.handleChange}  required/>
                  <input type="password" name="password"  placeholder="Password" 
                      onChange={this.handleChange}  required/>
                  <input type="submit" onClick={this.handleSubmit} value="Login"/>
                
                </div>
                <div className="hide-md-lg">
          <p>Or sign in manually:</p>
        </div>
        <div className="col2">
                  <input type="text" name="fname_new" placeholder="First Name" onChange={this.handleChange}  required/>
                  <input type="text" name="lname_new" placeholder="Last Name" onChange={this.handleChange}  required/>
                <input type="text" name="password_new" placeholder="Password" onChange={this.handleChange}  required/>
                <input type="text" name="confirm_password_new" placeholder="Re Enter Password" onChange={this.handleChange}  required/>
                <input type="text" name="contact" placeholder="Contact Number" onChange={this.handleChange}  required/>
                <input type="text" name="emailId_new" placeholder="Email Id" onChange={this.handleChange}  required/>
                <input type="text" name="org" placeholder="Organization" onChange={this.handleChange}  required/>
                <input type="button" onClick={this.handleClick} value="Sign Up"/>
                  </div>
                 </div>
                 </form>
          </div>
          
               
            );
          }


}
