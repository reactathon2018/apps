import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { getUsersQuery } from '../queries/queries';
import { ListGroup, ListGroupItem , Badge } from 'reactstrap';


// components
// import BookDetails from './BookDetails';

class UserList extends Component {
    render(){
        var data = this.props.data;
        if(data.loading){
            return( <div>Loading users...</div> );
        } else {

            return (<ListGroup>
                        { data.users.map(user => {
                            return <ListGroupItem key={user.id} color="success">{ user.firstName } { user.lastName}<Badge pill>{ user.id }</Badge></ListGroupItem>
                        })}
                    </ListGroup>);
        }
    }
}

export default graphql(getUsersQuery)(UserList);
