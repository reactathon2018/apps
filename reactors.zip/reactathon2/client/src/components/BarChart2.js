
import React, { Component } from 'react';
import * as d3 from 'd3';
import {withFauxDOM} from 'react-faux-dom';

class BarChart extends React.Component {
    componentDidMount () {
      const faux = this.props.connectFauxDOM('div', 'chart')
      d3.select(faux)
        .append('div')
        .html('World')
      this.props.animateFauxDOM(800)

      //Bar chart Start --------------------------------------------------------------->
      var data = this.props.data;
      var margin = {top: 20, right: 20, bottom: 30, left: 40},
      width = 960 - margin.left - margin.right,
      height = 500 - margin.top - margin.bottom;
      var colors = ['steelblue'];

      var x = d3.scaleBand()
          .range([0, width])
          .padding(0.05);
          
      var y = d3.scaleLinear()
          .range([height, 0]);

      var chart = document.getElementById('chart2');
          
      var svg = d3.select(chart)
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
          .append("g")
          .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      x.domain(data.map(function(d) { return d.date; }));
      y.domain([0, d3.max(data, function(d) { return d.event.count; })]).nice();

      var tooltip = d3.select("body").append("div").attr("class", "toolTip");
      var text = svg.selectAll('text').data(data).enter().append('text')
        .text(function(d) {
              return d.event.name;
        })
        .attr('x', function(d,i) {
            return i * x.bandwidth()+x.bandwidth()/2;
        })
        .attr('y', function(d,i){
            return
        });

      text.attr('fill', 'black')
          .attr("font-family", "sans-serif")
          .attr('font-size', '10')
          .attr('font-weight', 'bold')
          .attr("text-anchor", "middle");

      svg.selectAll(".bar")
          .data(data)
          .enter().append("rect")
          .attr("class", "bar")
          .attr("x", function(d) { return x(d.date); })
          .attr("width", x.bandwidth())
          .attr("y", function(d) { return y(d.event.count); })
          .attr("height", function(d) { return height - y(d.event.count); })
          .attr('fill', function (d, i) {
            return colors[i % colors.length];
          })
          .on("mouseover", function() { tooltip.style("display", null); d3.select(this).attr("fill", "#588C73")})
          .on("mousemove", function(d){
            tooltip
              .style("left", d3.event.pageX - 50 + "px")
              .style("top", d3.event.pageY - 70 + "px")
              .style("display", "inline-block")
              .html("<b>Name:</b>"+(d.event.name) + "<br>" + "<b>Participants:</b>" + (d.event.count));
        })
        .on("mouseout", function(d){ tooltip.style("display", "none");d3.select(this).attr("fill", "steelblue")});

      svg.append("g")
          .attr("transform", "translate(0," + height + ")")
          .call(d3.axisBottom(x)
          .tickFormat(d3.timeFormat("%Y-%m-%d")))
          ;
    
      svg.append("g")
          .call(d3.axisLeft(y).ticks(3));
      
    }
    
   
    render () {
      return (
        <div>
        </div>
      )
    }
  }
   
  BarChart.defaultProps = {
    chart: 'loading'
  }
   
  export default withFauxDOM(BarChart)