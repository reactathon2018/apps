const express = require('express');
const graphqlHTTP = require('express-graphql');
const schema = require('./schema/schema');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// allow cross-origin requests
app.use(cors());

// connect to mlab database
mongoose.connect('mongodb://localhost/db')
mongoose.connection.once('open', () => {
    console.log('conneted to database');
});

// bind express with graphql
app.use('/graphql', graphqlHTTP({
    schema,
    graphiql: true
}));

app.listen(4000, () => {
    console.log('now listening for requests on port 4000');
});

//Login Backend 


var Schema = mongoose.Schema;
  var userSchema = new Schema({
    fName:String,
    lName:String,
    emailId:String,
    contact:Number,
    details:Object,
    org:String
    }
  );

  var loginSchema = new Schema({
    username:String,
    password:String
   
    }
  );
  
  var User = mongoose.model('user', userSchema,'user');
  var myUser = mongoose.model('login_mapping', loginSchema,'login_mapping');

app.get('/validateUser', function (req, res) {
  const emailId=req.query.emailId;
  mongoose.connect('mongodb://localhost/db');
mongoose.connection.once('open',()=>{
    console.log(`db is connected`);
    
});

  
  User.findOne({ 'emailId': emailId }, 'emailId', function (err, user) {
    if (err) return handleError(err);
    // Prints "Space Ghost is a talk show host".
    if(user!=null && user.emailId==emailId){
      console.log('User already exists');
      res.send('User already exists!');
   
    }else{
      console.log('New User ');
      res.send('New User'); 
      
    }
    console.log(user);
  });



});
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/addUser", (req, res) => {
  mongoose.connect('mongodb://localhost/db');
  mongoose.connection.once('open',()=>{
      console.log(`db is connected`);
 
});



console.log(req.body) ;
var myData = new User(req.body);
 myData.save()
 .then(item => {
 res.send("item saved to database");
 })
 .catch(err => {
 res.status(400).send("unable to save to database");
 });
});


app.post("/addPasswordMapping", (req, res) => {
  mongoose.connect('mongodb://localhost/db');
  mongoose.connection.once('open',()=>{
      console.log(`db is connected`);
 
});


  
  
  

console.log(req.body) ;
var myData = new myUser(req.body);
 myData.save()
 .then(item => {
 res.send("item saved to database");
 })
 .catch(err => {
 res.status(400).send("unable to save to database");
 });
});

app.post('/validateLogin', function (req, res) {
  const emailId=req.query.emailId;
  mongoose.connect('mongodb://localhost/db');
mongoose.connection.once('open',()=>{
    console.log(`db is connected`);
    
});




let userName=req.body.username;  
let password=req.body.password; 
var login_mapping = mongoose.model('login_mapping', loginSchema,'login_mapping');
login_mapping.findOne({ 'username': userName }, 'password', function (err, login) {
    if (err) return handleError(err);
    // Prints "Space Ghost is a talk show host".
    if(login==null){

      res.send('No record');
    }
     else if (login!=null && login.password==password){
      console.log('password Matching');
      res.send('Pass');
   
    }else{
      console.log('password not Matching');
      res.send('Fail'); 
      
    }
    console.log(login);
  });



});




app.post("/runQuery", (req, res) => {
  mongoose.connect('mongodb://localhost/db');
  mongoose.connection.once('open',()=>{
      console.log(`db is connected`);
 
});
var table=req.body.tableName;
var query=req.body.query;
var reqSchema =req.body.reqSchema ;
var selects = req.body.selects
console.log('table '+table+' query '+query+' reqSchema '+reqSchema+' selects '+selects) ;


  var mySchema = new Schema(reqSchema);
  
  var myUser = mongoose.model(table, mySchema,table);

  User.findOne(query, selects, function (err, result) {
    if (err) return handleError(err);
  console.log(result)  ;
        res.send(result);
   
    
  });
});






