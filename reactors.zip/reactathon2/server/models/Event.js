const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const eventSchema = new Schema({
    id : Number,
    name:String,
    venue:String,
    time:String,
    prize:String,
    description:String,
    userId : Number
});

module.exports = mongoose.model('Event', eventSchema);