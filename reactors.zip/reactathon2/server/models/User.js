const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    id : Number,
    firstName:String,
    lastName:String,
    emailId:String,
    contact:Number,
    org:String,
    eventId : Number
});

module.exports = mongoose.model('User', userSchema);