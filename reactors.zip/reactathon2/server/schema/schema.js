const graphql = require('graphql');
const User = require('../models/User');
const Event = require('../models/Event');
const _ = require('lodash');

const {
    GraphQLObjectType,
    GraphQLString,
    GraphQLSchema,
    GraphQLID,
    GraphQLInt,
    GraphQLList,
    GraphQLNonNull
} = graphql;

//user type:::: model
const UserType  = new GraphQLObjectType({
    name : 'User',
    fields: ()=>({
        id: { type : GraphQLID },
        firstName : { type : GraphQLString },
        lastName : { type : GraphQLString },
        emailId : { type : GraphQLString },
        contact : { type : GraphQLInt },
        org : { type : GraphQLString },
        // eventId : { type : GraphQLInt },
        eventsParticipated: {
            type: EventType,
            resolve(parent, args){
                return Event.findById(parent.userId);
            }
        }
    })
});

//event type:::: model
const EventType  = new GraphQLObjectType({
    name : 'Event',
    fields: ()=>({
        id: { type : GraphQLID },
        name : { type : GraphQLString },
        venue : { type : GraphQLString },
        time : { type : GraphQLString },
        prize : { type : GraphQLString },
        description : { type : GraphQLString },
        usersParticipated: {
            type: new GraphQLList(UserType),
            resolve(parent, args){
                return User.find({ userId: parent.id })
            }
        }
    })
});

//root query
const RootQuery = new GraphQLObjectType({
    name : 'RootQueryType',
    fields : {
        //to search user by id
        user : {
            type: UserType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return User.findById(args._id);
            }
        },
        //to search all users
        users : {
            type: new GraphQLList(UserType),
            resolve(parent, args){
                return User.find({});
            }
        },
        //to search event by id
        event : {
            type: EventType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return Event.findById(args._id);
            }
        },
        //to search all events
        events : {
            type: new GraphQLList(EventType),
            resolve(parent, args){
                return Event.find({});
            }
        },
        
    }
});

const Mutation = new GraphQLObjectType({
    name: 'Mutation',
    fields: {       
        addUser: {
            type: UserType,
            args: {
                id: { type : new GraphQLNonNull(GraphQLID) },
                eventId: { type : GraphQLID },
                firstName: { type : new GraphQLNonNull(GraphQLString) },
                lastName: { type : GraphQLString },
                emailId: { type :GraphQLString },
                contact: { type : GraphQLInt },
                org: { type : GraphQLString }
            },
            resolve(parent, args){
                let user = new User({
                    id: args.id,
                    eventId : args.eventId,
                    firstName: args.firstName,
                    lastName: args.lastName,
                    emailId: args.emailId,
                    org: args.org,
                    contact: args.contact
                });
                return user.save();
            }
        },
        addEvent: {
            type: EventType,
            args: {
                id: { type : new GraphQLNonNull(GraphQLID) },
                name : { type : new GraphQLNonNull(GraphQLString)},
                venue : { type : new GraphQLNonNull(GraphQLString)},
                time : { type : new GraphQLNonNull(GraphQLString)},
                prize : { type : new GraphQLNonNull(GraphQLString)},
                description : { type : GraphQLString},
                userId : { type : GraphQLID},
            },
            resolve(parent, args){
                let user = new User({
                    id: args.id,
                    name : args.name,
                    venue: args.venue,
                    lastName: args.lastName,
                    time: args.time,
                    prize: args.prize,
                    description: args.description,
                    userId: args.userId
                });
                return user.save();
            }
        }
    }
});

module.exports = new GraphQLSchema({
    query: RootQuery,
    mutation: Mutation
});
