module.exports = function(app, db) {

    app.post('/getprofile', function(req, res) {
        getProfile(db,req.body.userid, res)
    })

    app.post('/editprofile', function(req, res) {
        editProfile(db,req.body.userid,req.body.expe,req.body.skill,req.body.location,req.body.education, res)
    })
};

function getProfile(db, userid, res){
    var query = { userid: userid};
    db.collection("users").find(query).toArray(function(err, result) {
        if (err) throw err;
        if(result.length>0){
            var ret = {  error: "0", userid : result[0].userid, role: result[0].role, name : result[0].name, email : result[0].email, exp:result[0]["exp"]!=null?result[0]["exp"]:"", skill:result[0]["skill"]!=null?result[0]["skill"]:"",
                location:result[0]["location"]!=null ?result[0]["location"]:"",education:result[0]["education"]!=null?result[0]["education"]:""}
            res.send(ret)
        }else{
            res.send("{\"error\":\"1\",\"errorMsg\":\"User Not Found or invalid Details\"}")
        }
    });
}

function editProfile(db, userid,expe,skill,location,education, resp){
    var query = { userid: userid };
    var newvalues = { $set: {exp: expe,skill:skill,location:location,education:education} };
    db.collection("users").updateOne(query, newvalues, function(err, res) {
        if (err) {
            resp.send("{\"error\":\"1\",\"errorMsg\":\"internal error\"}")
        }
        var ret = {  error: "0", message : "successfully updated"}
        resp.send(ret);
    });
}