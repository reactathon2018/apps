module.exports = function(app, db) {

    app.post('/createjob', function(req, res) {
        createJob(db,req.body.userid,req.body.title,req.body.desc,req.body.expe,req.body.location,req.body.profile,req.body.skill, res)
    })

    app.post('/listjob', function(req, res) {
        listJob(db,req.body.userid,req.body.skill,req.body.page, res)
    })

    app.post('/applyjob', function(req, res) {
        applyJob(db,req.body.userid,req.body.jobid, res)
    })
};
function createJob( db, userid, title,desc,expe,location,profile,skill,resp) {
    var jobcode ="vz"+ new Date().getTime()+"";
    var obj = { jobcode: jobcode, createdby: userid , jobtitle: title, desc:desc, expe:expe, location: location, profile: profile, skill: skill, createdat:new Date().toISOString().substring(0, 10),isexpired:false};
    db.collection("jobtable").insertOne(obj, function(err, res) {
        if (err) throw err;
        var ret = { status: "1", error: "0", jobcode : jobcode}
        resp.send(ret)
    });
};

function applyJob(db, userid,jobid, resp){
    var query = { jobcode: jobid };
    db.collection("jobtable").find(query).toArray(function(err, result) {
        if (err) throw err;
        if(result.length>0){
            var applied = result[0]["applied"]
            if(applied === undefined || applied.length == 0){
                applied = ""+userid
            }else{
                applied =applied+","+userid
            }
            var newvalues = { $set: {applied: applied} };
            db.collection("jobtable").updateOne(query, newvalues, function(err, res) {
                if (err) throw err;
                var ret = {  error: "0", message : "successfully applied"}
                resp.send(ret);
            });

        }else{
            resp.send("{\"error\":\"1\",\"errorMsg\":\"Job Not Found or invalid Details\"}")
        }
    });

}
function listJob( db, userid, skill , page, resp) {
    var finallist =[]
    db.collection("jobtable").find({}).toArray(function(err, result) {
        if (err) throw err;
            for (var i = 0; i< 10*page; i++){
                if(result.length> i && skill != null && skill != undefined && result[i].skill.toLowerCase().includes(skill.toLowerCase())){
                    var applied = result[i]["applied"]
                    if(applied === undefined  || applied.length == 0){
                        applied = ""
                        result[i]["totalapplied"] = 0
                    }else {
                        var array = applied.split(',')
                        result[i]["totalapplied"] = array.length
                    }
                    if(applied.includes(userid)) {
                        result[i]["applied"] = true
                    }else
                        result[i]["applied"] = false

                    finallist.push(result[i])
                }else if(result.length> i){
                    var applied = result[i]["applied"]
                    if(applied === undefined  || applied.length == 0){
                        applied = ""
                        result[i]["totalapplied"] = 0
                    }else {
                        var array = applied.split(',')
                        result[i]["totalapplied"] = array.length
                    }
                    if(applied.includes(userid)) {
                        result[i]["applied"] = true
                    }else
                        result[i]["applied"] = false

                    finallist.push(result[i])
                }
            }
            var jsn = {articles:finallist}
            resp.send(jsn)
    });

};