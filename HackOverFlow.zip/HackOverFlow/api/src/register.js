
module.exports = function(app, db) {

    app.post('/register', function(req, res) { writeUserData(db,req.body.email,req.body.name,req.body.password, req.body.role,res)})
};


    function writeUserData( db, femail, fname,fpassword, frole,resp) {
        // let buff = new Buffer(email);
        // let userid = buff.toString('base64');

        var query = { email: femail };
        db.collection("users").find(query).toArray(function(err, result) {
            if (err) throw err;
            if(result.length==0){
                let buff = new Buffer(femail);
                let userid = buff.toString('base64');
                var obj = { name: fname, email: femail , password: fpassword, role:frole, userid:userid};
                db.collection("users").insertOne(obj, function(err, res) {
                    if (err) throw err;
                    var ret = { status: "1", error: "0", userid : userid}
                    resp.send(ret)
                });
            }else{
                resp.send("{\"error\":\"1\",\"errorMsg\":\"User already exist\"}")
            }
        });
    };