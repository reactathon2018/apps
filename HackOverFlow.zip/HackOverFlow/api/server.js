var express =  require("express");
var bodyParser = require('body-parser');
var morgan = require('morgan');
var passport = require('passport');
var jwt = require('jsonwebtoken');
var firebase = require("firebase");
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017";

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("jobportal");
    require('./src/login.js')(app, dbo);
    require('./src/register.js')(app, dbo);
    require('./src/job.js')(app, dbo);
    require('./src/profile.js')(app, dbo);

});
var config = {
    apiKey: "AIzaSyCTQVSP3laOzipEHfVXRM38MGltVqregCU",
    authDomain: "jobportal-ab292.firebaseapp.com",
    databaseURL: "https://jobportal-ab292.firebaseio.com",
    projectId: "jobportal-ab292",
    storageBucket: "",
    messagingSenderId: "387478268885"
};
firebase.initializeApp(config);
var database = firebase.database();
var app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


var port =8086;

app.get('/', function(req, res) { res.send('Hello World!')})

app.listen(port, function() { console.log('Server running on port '+port)})