//import React, { Component } from 'react';
//import '../App.css';


// class ScheduledInterviews extends Component {
//     render() {
//         return (
//             <div id="CarrerBanner">
// 	Look at the Interviews you have scheduled For
//             </div>
//         );
//     }
// }

// export default ScheduledInterviews;

import React, { Component } from 'react';
import '../App.css';
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import PropTypes from 'prop-types';

const NoteService = require('../../services/note-service');


class ScheduledInterviews extends Component {
    constructor(props) {
        super(props);
        console.log('User Profile Data in  Search JOBS',this.props);
        const  UserProfiledata = {
            id: '', 
            candidateId: '', 
            candidateName: '', 
            candidateAge: '', 
            TotalExperience: '', 
            skillset: '', 
            contactNo: ''
        };
        const me = this;
        this.state = {
            data:[]
        };
		
        NoteService
            .listInterview(props.UserProfiledata.candidateId)
            .then(res => {
                console.log(res);
                //me.setState({data: res});
                me.setState({data:res});
                console.log(me.state);
                return;
            })
            .catch(error => {
                console.log(error);
                return;
            });
        
        this.columns = [{
            Header: 'Job Code',
            accessor: 'job_id' // String-based value accessors!
        }, {
            Header: 'Candidate Id',
            accessor: 'candidateId'
        }, {
            Header: 'Candidate Name',
            accessor:'candidateName' // Custom value accessors!
        },{
            Header: 'Role',
            accessor:'role' // Custom value accessors!
        },{
            Header: 'Interview Date',
            accessor: 'interviewDate'
        }
            //  {
            //   Header: props => <span>Applied On</span>, // Custom header components!
            //   accessor: 'reportingManager.age'
            // }
        ];
    }

	
    render() {
        return (
            <div id="CarrerBanner">
                <h3>You have applied for below openings.</h3>
                <ReactTable data={this.state.data} columns={this.columns} minRows="5"/>
            </div>
        );
    }
}
ScheduledInterviews.propTypes = {
    UserProfiledata: PropTypes.object
    // add .isRequired here if "params" is required
};
export default ScheduledInterviews;