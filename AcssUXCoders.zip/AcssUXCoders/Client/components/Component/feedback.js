import React, { Component } from 'react';
import '../App.css';


class ScheduledInterviews extends Component {
    render() {
        return (
            <div id="CarrerBanner">
        Kindly Provide your feedback for the Interviews you have attended..
            </div>
        );
    }
}

export default ScheduledInterviews;
