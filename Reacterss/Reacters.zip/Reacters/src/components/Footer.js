import React from 'react';


class Footer extends React.Component {
  render() {
    return (
      <div className="container-fluid fixed-bottom">
        <small>Copyright &copy; Verizon Job Portal 2018  </small>
      </div>
    );
  }
}

export default Footer;
