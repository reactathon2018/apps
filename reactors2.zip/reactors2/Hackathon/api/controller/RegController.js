'use strict';


var mongoose = require('mongoose'),
Team = mongoose.model('Team');

exports.create_a_team = function(req, res) {
    var new_team = new Team(req.body);
    new_team.save(function(err, task) {
      if (err)
        res.send(err);
      res.json(task);
    });
  };