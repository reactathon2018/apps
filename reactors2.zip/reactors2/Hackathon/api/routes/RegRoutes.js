'use strict';
module.exports = function(app) {
  var regController = require('../controller/RegController');

  // regController Routes
  app.route('/registerTeams')
    .post(regController.create_a_team);


};