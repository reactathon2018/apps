'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var TeamRegisterSchema = new Schema({
  name: {
    type: String,
    required: 'Kindly enter the name of the task'
  },
  EventId: {
    type: String,
    required: ''
  },
  Participants:{ 
      type:[String],
      required:'Email id of the participants'}

  
});

module.exports = mongoose.model('Team', TeamRegisterSchema,'Team');