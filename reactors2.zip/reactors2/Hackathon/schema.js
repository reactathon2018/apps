const graphql = require('graphql');
const _ = require('lodash');

const User = require('../model/User');

const {
    GraphQLObjectType,
    GraphQLString,
    GraphQLSchema,
    GraphQLID,
    GraphQLInt,
    GraphQLList,
    GraphQLNonNull
} = graphql;


//user details::::
const UserType  = new GraphQLObjectType({
    name : 'User',
    fields: ()=>({
        id: { type : GraphQLID },
        firstName : { type : GraphQLString },
        lastName : { type : GraphQLString },
        emailId : { type : GraphQLString },
        contact : { type : GraphQLInt }
    })
});

const Event =new GraphQLObjectType({
    name : 'Event',
    fields: ()=>({
        id: {type : GraphQLID},
        name : {type: GraphQLString},
        venue : {type: GraphQLString},
        startDate : {type : Date},
        duration : {type: GraphQLInt},
        status :  {type : GraphQLString},
        techStack : { type : GraphQLString},
        registrationCloseDate : {scalar : Date},
        maxTeamSize :{type: GraphQLInt},
        description :  {type : GraphQLString},
        prize : { type : GraphQLString}
    })
})
//root query
const RootQuery = new GraphQLObjectType({
    name : 'RootQueryType',
    fields : {
        user : {
            type: UserType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return User.findById(args.id);
            }
        },
        users : {
            type: new GraphQLList(UserType),
            resolve(parent, args){
                return User.find({});
            }
        }
    }
});


const Mutation = new GraphQLObjectType({
    name: 'Mutation',
    fields: {       
        addUser: {
            type: UserType,
            args: {
                id: { type : new GraphQLNonNull(GraphQLID) },
                firstName: { type : new GraphQLNonNull(GraphQLString) },
                lastName: { type : new GraphQLNonNull(GraphQLString) },
                emailId: { type : new GraphQLNonNull(GraphQLString) },
                contact: { type : new GraphQLNonNull(GraphQLInt) }
            },
            resolve(parent, args){
                let user = new User({
                    id: args.id,
                    firstName: args.firstName,
                    lastName: args.lastName,
                    emailId: args.emailId,
                    contact: args.contact
                });
                return user.save();
            }
        }
    }
});

module.exports = new GraphQLSchema({
    query : RootQuery,
    mutation : Mutation
});