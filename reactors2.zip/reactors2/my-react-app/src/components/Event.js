import React, { Component } from 'react';
import { 
    Button,
    Modal,
    FormGroup,
    ControlLabel,
    FormControl,
    HelpBlock
 } from 'react-bootstrap';
import EventRegistration from './EventRegistration';

export default class Event extends Component {
    constructor(){
        super();
        this.state = {render:''}
        
    }
    handleClick(compName, e){
        console.log(compName);
        this.setState({render:compName}); 
        ;  
    }
    _renderSubComp(){
        switch(this.state.render){
          case 'EventRegistration': return  <EventRegistration/>
        }
    }
    render() {
        return (
            <div className="Event">

                <h1 className="App-title">Active Events</h1>
                {/* <div >{this.prop.data.name}</div>
                <div >{this.prop.data.venue}</div>
                <div >{this.prop.data.time}</div>
                <div >{this.prop.data.duration}</div>
                <div >{this.prop.data.techStack}</div>
                <div >{this.prop.data.prize}</div>
                <div >{this.prop.data.description}</div>
                <div >{this.prop.data.maxTeamSize}</div>
                <div eventResistrationClose>{this.prop.data.registrationCloseDate}</div>
                */}
                <Button bsStyle="primary"  onClick={this.handleClick.bind(this, 'EventRegistration')}>Register</Button>
                {this._renderSubComp()}
            </div>
        );
    }
}