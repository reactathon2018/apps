import { gql } from 'apollo-boost';
import { graphql } from 'graphql';


const getActiveEvent = gql`
  query {
    event(status: "Active") {
      name
      venue
      time
      duration
      techStack
      prize
      description
      maxTeamSize
      registrationCloses

    }
  }
`

const addTeam = gql`
    mutation AddTeam($name: String!, $emailIdOfMembers: [String]!,$eventId:String!){
        addTeam(name: $name, emailIdOfMembers: $emailIdOfMembers){
            name
            emailId
        }
    }
`;

export default graphql(getActiveEvent)
export default graphql(addTeam)