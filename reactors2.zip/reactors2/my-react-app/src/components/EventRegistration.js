import React, { Component } from 'react';

import './EventRegistration.css';
     
import { 
    Button,
    Modal,
    FormGroup,
    ControlLabel,
    FormControl,
    HelpBlock
 } from 'react-bootstrap';
 

function  FieldGroup({ id, label, help, ...props }) {
    return (
      <FormGroup controlId={id}>
        <ControlLabel>{label}</ControlLabel>
        <FormControl {...props} />
        {help && <HelpBlock>{help}</HelpBlock>}
      </FormGroup>
    );
  }
export default class EventRegistration extends Component {
    constructor(props, context) {
        super(props, context);

        this.handleHide = this.handleHide.bind(this);
    
        this.state = {
          show: true
        };
      }
    
      handleHide() {
        this.setState({ show: false });
      }
      handleSubmit(){
          console.log('suybnmf');
          fetch('http://localhost:5000/validateLogin', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
       form.
      
      })
    })
      }
    render() {
        alert("HI");
        return (
            <div className="modal-container" style={{ height: 500 }}>
                <Modal show={this.state.show} onHide={this.handleClose} container={this} bsSize="large" aria-labelledby="contained-modal-title-lg">
                    <Modal.Header>
                        <Modal.Title>Team Registration</Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                        <form onSubmit={(e) => {this.handleSubmit(); e.preventDefault();}}>
                            <FieldGroup
                                id="formControlsName"
                                type="text"
                                label="Team Name"
                                placeholder="Enter text"
                            />
                            <FieldGroup
                                id="formControlsEmail1"
                                type="email"
                                label=" Participant1"
                                placeholder="Enter email"
                            />
                            <FieldGroup
                                id="formControlsEmail2"
                                type="email"
                                label=" Participant2"
                                placeholder="Enter email"
                            /> 
                            <FieldGroup
                            id="formControlsEmail3"
                            type="email"
                            label=" Participant3"
                            placeholder="Enter email"
                        />
                        <Button type="submit" >Submit</Button>
                        </form>
                    </Modal.Body>

                </Modal>
                </div>
        );
    }
}