import React, { Component } from 'react';
import './Home.css';


class Carrers extends Component {
    render() {
        return(
<div className ='fakeimg'></div>


);
}
}
export default Carrers;
