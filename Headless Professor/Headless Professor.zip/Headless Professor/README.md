# intelligent Job Portal

The Application has client and server part