export const AUTH_CONFIG = {
  domain: 'reactijp.auth0.com',
  clientId: 'vR0H4rVqqDigDGTJMBfxBM0os2QJoysg',
  callbackUrl: 'http://localhost:3000/callback'
}
