import React from "react";
// nodejs library that concatenates classes
import classNames from "classnames";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";

// @material-ui/icons

// core components
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Button from "components/CustomButtons/Button.jsx";
import Card from "components/Card/Card.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import teamStyle from "assets/jss/material-kit-react/views/landingPageSections/teamStyle.jsx";

import team1 from "assets/img/faces/avatar.jpg";
import team2 from "assets/img/faces/christian.jpg";
import team3 from "assets/img/faces/kendall.jpg";

class TeamSection extends React.Component {
  render() {
    const { classes } = this.props;
    const imageClasses = classNames(
      classes.imgRaised,
      classes.imgRoundedCircle,
      classes.imgFluid
    );
    return (
      <div className={classes.section}>
        <h2 className={classes.title}>Events</h2>
        <div>
          <GridContainer>
            <GridItem xs={12} sm={12} md={4}>
              <Card plain>
                <GridItem xs={12} sm={12} md={6} className={classes.itemGrid}>
                 
                </GridItem>
                <h4 className={classes.cardTitle}>
                  Healathon
                  <br />                 
                </h4>
                <CardBody>
                  <p className={classes.description}>
                    Aim to make a Real Time Non-Prod environments more efficient with Self Healing capabilities for all the Applications..
                  </p>
                  <br/>
                </CardBody>
                <CardFooter className={classes.justifyCenter}>
                <Button
                  color="success"
                  size="lg"
                  href="/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View More
                </Button>
                </CardFooter>
              </Card>
            </GridItem>
            <GridItem xs={12} sm={12} md={4}>
              <Card plain>
                <GridItem xs={12} sm={12} md={6} className={classes.itemGrid}>
                 
                </GridItem>
                <h4 className={classes.cardTitle}>
                  Reactathon
                  <br />
              
                </h4>
                <CardBody>
                  <p className={classes.description}>
                    Calling all ideators, coders and testers to act with the new Techstack - ReactJS, Redux, GraphQL, React Native, NodeJS, Charting Libraries and more..
                  </p>
                </CardBody>
                <CardFooter className={classes.justifyCenter}>
                <Button
                  color="success"
                  size="lg"
                  href="/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View More
                </Button>
                  
                </CardFooter>
              </Card>
            </GridItem>
            <GridItem xs={12} sm={12} md={4}>
              <Card plain>
                <GridItem xs={12} sm={12} md={6} className={classes.itemGrid}>
               
                </GridItem>
                <h4 className={classes.cardTitle}>
                 Speedathon
                  <br />
                  
                </h4>
                <CardBody>
                  <p className={classes.description}>
                    Learn, Build, Automate
                  <br/> Model and make a Difference!!!</p>
                  <br />
                  <br/>
                </CardBody>
                <CardFooter className={classes.justifyCenter}>
                <Button
                  color="danger"
                  size="lg"
                  href="/login-page"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Register
                </Button>
                </CardFooter>
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}

export default withStyles(teamStyle)(TeamSection);
