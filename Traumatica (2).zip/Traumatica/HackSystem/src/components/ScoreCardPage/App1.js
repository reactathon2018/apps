import React, { Component } from 'react';

import ScoreCard from './ScoreCard';

class App1 extends Component {
  render() {
    return (
            <ScoreCard/>
    );
  }
}

export default App1;