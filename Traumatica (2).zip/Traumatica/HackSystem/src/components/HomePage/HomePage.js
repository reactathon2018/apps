import React, { Component } from 'react';
import NavBar from '../NavBar/NavBar';

class HomePage extends Component {
  render() {
    return (
      <div className="HomePage">
        
        <h2>Hackathon Management System</h2>
        <NavBar />
      </div>
  
    );
  }
}

export default HomePage;
