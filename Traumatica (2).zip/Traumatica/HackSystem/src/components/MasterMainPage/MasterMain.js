import React, { Component } from 'react';
import MasteMainForm from './MasteMainForm';

import './MasterMain.css';

class MasteMain extends Component {
  render() {
    return (
      <div className="MasterMain">
        <MasterMain />
      </div>
    );
  }
}

export default MasterMain;
