module.exports = require('react-project/test').KarmaConf

